package com.akristic.simplelastquake

import android.app.LoaderManager
import android.content.Context
import android.content.Intent
import android.content.Loader
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.AdapterView.OnItemClickListener
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.util.*

class EarthquakeActivity : AppCompatActivity(), LoaderManager.LoaderCallbacks<List<Earthquake>?> {
    /** Adapter for the list of earthquakes  */
    private var mAdapter: EarthquakeAdapter? = null

    /** TextView that is displayed when the list is empty  */
    private var mEmptyStateTextView: TextView? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.earthquake_activity)

        // Find a reference to the {@link ListView} in the layout
        val earthquakeListView = findViewById(R.id.list) as ListView
        mEmptyStateTextView = findViewById(R.id.empty_view) as TextView
        earthquakeListView.emptyView = mEmptyStateTextView

        // Create a new adapter that takes an empty list of earthquakes as input
        mAdapter = EarthquakeAdapter(this, ArrayList<Earthquake>())

        // Set the adapter on the {@link ListView}
        // so the list can be populated in the user interface
        earthquakeListView.adapter = mAdapter

        // Set an item click listener on the ListView, which sends an intent to a web browser
        // to open a website with more information about the selected earthquake.
        earthquakeListView.onItemClickListener = OnItemClickListener { adapterView, view, position, l -> // Find the current earthquake that was clicked on
            val currentEarthquake: Earthquake? = mAdapter!!.getItem(position)

            // Convert the String URL into a URI object (to pass into the Intent constructor)
            val earthquakeUri = Uri.parse(currentEarthquake?.url)

            // Create a new intent to view the earthquake URI
            val websiteIntent = Intent(Intent.ACTION_VIEW, earthquakeUri)

            // Send the intent to launch a new activity
            startActivity(websiteIntent)
        }

        // Get a reference to the ConnectivityManager to check state of network connectivity
        val connMgr = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

        // Get details on the currently active default data network
        val networkInfo = connMgr.getNetworkCapabilities(connMgr.activeNetwork)

        // If there is a network connection, fetch data
        if (networkInfo != null && networkInfo.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) {
            // Get a reference to the LoaderManager, in order to interact with loaders.
            val loaderManager = loaderManager

            // Initialize the loader. Pass in the int ID constant defined above and pass in null for
            // the bundle. Pass in this activity for the LoaderCallbacks parameter (which is valid
            // because this activity implements the LoaderCallbacks interface).
            loaderManager.initLoader(EARTHQUAKE_LOADER_ID, null, this)
        } else {
            // Otherwise, display error
            // First, hide loading indicator so error message will be visible
            val loadingIndicator: View = findViewById(R.id.loading_indicator)
            loadingIndicator.visibility = View.GONE

            // Update empty state with no connection error message
            mEmptyStateTextView!!.setText(R.string.no_internet_connection)
        }
    }

    override fun onCreateLoader(i: Int, bundle: Bundle): Loader<List<Earthquake>?> {
        // Create a new loader for the given URL
        return EarthquakeLoader(this, USGS_REQUEST_URL)
    }

    override fun onLoadFinished(loader: Loader<List<Earthquake>?>, earthquakes: List<Earthquake>?) {
        // Hide loading indicator because the data has been loaded
        val loadingIndicator: View = findViewById(R.id.loading_indicator)
        loadingIndicator.visibility = View.GONE

        // Set empty state text to display "No earthquakes found."
        mEmptyStateTextView?.setText(R.string.no_earthquakes)

        // Clear the adapter of previous earthquake data
        mAdapter?.clear()

        // If there is a valid list of {@link Earthquake}s, then add them to the adapter's
        // data set. This will trigger the ListView to update.
        if (earthquakes != null && !earthquakes.isEmpty()) {
            mAdapter?.addAll(earthquakes)
        }
    }

    override fun onLoaderReset(loader: Loader<List<Earthquake>?>) {
        // Loader reset, so we can clear out our existing data.
        mAdapter?.clear()
    }

    companion object {
        private val LOG_TAG = EarthquakeActivity::class.java.name

        /** URL for earthquake data from the USGS dataset  */
        private const val USGS_REQUEST_URL = "http://earthquake.usgs.gov/fdsnws/event/1/query?format=geojson&orderby=time&minmag=2&limit=10"

        /**
         * Constant value for the earthquake loader ID. We can choose any integer.
         * This really only comes into play if you're using multiple loaders.
         */
        private const val EARTHQUAKE_LOADER_ID = 1
    }
}
